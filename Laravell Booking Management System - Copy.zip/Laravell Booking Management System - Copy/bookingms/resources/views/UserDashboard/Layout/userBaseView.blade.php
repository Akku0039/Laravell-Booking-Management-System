@section('style')
<style>
.bi{
    vertical-align:-.125em;
    fill: currentColor;
}
.nav-scroller{
    position:relative;
    z-index:2;
    height :2.75rem;
    overflow-y:hidden;
}
.nav-scoller .nav{
    display:flex;
    flex-wrap:nowrap;
    padding-bottom:1rem;
    margin-top:-1px;
    overflow-x=auto;
    text-align:center;
    white-space:nowrap;
    -webkit-overflow-scrolling:touch;
}
body{
    font-size:.875rem;

}
.feather{
    width:16px;
    height:16px;
}
.sidebar{
    position:fixed;
    top:0;
    bottom:0;
    left:0;
    z-index:100;
    padding:48px 0 0;
    box-shadow:inset -1px 0 0 rgba(0,0,0,1);
}
@media(maxwidth:767.98px){
    .sidebar{
        top:5rem;
    }
}
.sidebar-sticky{
    height:calc(100vh - 48px);
    overflow-x= hidden;
    overflow-y= ;

}
.sidebar .nav-link{
    font-weight:100;
    color:black;
}
.sidebar .nav-link .feather{
     margin-right:0px;
     color:grey;
}
.sidebar .nav-link .active{
    color:blue;
}
.sidebar .nav-link:hover .feather,
.sidebar .nav-link-active .feather{
    color:pink;
}
.sidebar-heading{
    font-size:.75rem;
}
.navbar-brand{
    padding-top:.75rem;
    paddind-bottom:.75rem;
    background-color:rgba(0,0,0,25);
    box-shadow:inset -1px 0 0 rgba(0,0,0,25);
}
.navbar .navbar-toggler{
    top=.25rem;
    right:1rem;
}
.navbar .form-control{
    padding:.75rem 1rem;
}
.form-control-dark{
    color:#fff;
    background-color:rgba(255,255,255,.1);
    border-color:rgba(255,255,255,.1);
}
.form-control-dark:focus{
    border-color:transparent;
    box-shadow:0 0 0 3px rgba(255,255,255,.25);
}
.dropbtn{
    background-color:#4CAF50;
    color:white;
    padding:16px;
    font-size:16px;
    border:none;
    cursor:pointer;
}
.dropdown{
    position:relative;
    display:inline-block;
}
.dropdown-content{
    display: none;
    position:absolute;
    background-color:white;
    min-width:160px;
    box-shadow:0px 8px 16px 0px rgba(0,0,0,0,2);
    z-index:1;
}
.dropdown-content .a{
   color:black;
   padding:17px 16px;
   text-decoration:none;
   display:block;
}
.dropdown-content a:hover{background:#f1f1f1}

.dropdown:hover .dropdown-content{
    display:block;
}
.dropdown:hover , dropbtn{
    background-color:#3e8e41;
}
</style>
@endsection
@section('content')
<header class="navbar navbar-dark sticky-top bg-dark flex-md-nowrap p-0 shadow">
    <a class="navbar-brand col-md-3 col-lg-2 me-0 px-3 fs-6" href="a">Compamy Name</a>
    <button class="navbar-toggler position-absolute d-md-none collapsed" type="button" data-bs-toggler="collapse" data-bs-target="#sidebar">
     <span class="navbar-toggler-icon"></span>
</button>
<div class="navbar-nav">
    <div class="nav-item text-nowrap">
        <a class="nav-link px-3" href="{{route('logout')}}">Sign out</a>
</div>
</div>
</header>
<div class="container-fluid">
     <div class="row">
        <nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
            <div class="position-sticky pt-3 sidebar-sticky">
                <ul class="nav flex-column"> 
                 <li class="nav-item">
                <a class="nav-link {{ Request::segment(1) == 'dashboard' ? 'active' : '' }}" aria-current="page" href="{{ route('dashboard.admin') }}">
                 <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round">
                   Dashboard
                 </svg>
                 </a>
             </li>
                 <li class="nav-item">
                <a class="nav-link {{ Request::segment(1) == 'booking' ? 'active' : '' }}"  href="{{ route('booking.all') }}">
                 <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round">
                   Bookings
                 </svg>
                 </a>
            </li>
                 <li class="nav-item">
                <a class="nav-link {{ Request::segment(1) == 'webpage' ? 'active' : '' }}" href="{{ route('webpage.index') }}">
                 <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round">
                   Webpage
                 </svg>
                 </a>
             </li>
                 <li class="nav-item">
                <a class="nav-link {{ Request::segment(1) == 'user' ? 'active' : '' }}" href="{{ route('user') }}">
                 <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round">
                   Users
                 </svg>
                 </a>
             </li> 
</ul>
<h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted text-uppercase">
    <span>Settings</span>
</h6>
<ul class="nav flex-column mb-2">
    <li class="nav-item">
        <a class="nav-link {{ Request::segment(1) == 'profile' ? 'active' : '' }}" href="{{ route('user.profile.get') }}">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round">
            </svg>
            Profile
            
        </a>
    </li>
</ul>
</div>
</nav>
<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4"><div class="chartjs-size-size-monitor-expand"></div>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">{{ucfirst(Request::segment(1))}}</h1>
</div>
@yield('dashContent')
</main>
</div>
</div>
@endsection
@section('customjs')
<script>
    CKEDITOR.replace('editor');
</script>
@endsection
